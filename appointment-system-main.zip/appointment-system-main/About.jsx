import React from "react";
import { assets } from "../assets/assets";

function About() {
  return (
    <div>
      <div className="text-center text-2xl pt-10 text-gray-500">
        <p>
          ABOUT<span className="text-gray-700 font-medium">US</span>
        </p>
      </div>
      <div className="my-10 flex flex-col md:flex-row gap-12">
        <img
          className="w-full md:max-w-[360px]"
          src={assets.about_image}
          alt=""
        />
        <div className="flex flex-col justify-center gap-6 md:w-2/4 text-sm text-gray-600">
          <p>
            Welcome to Med Connect, your trusted partner in healthcare. Easily
            book appointments with our network of experienced doctors and take
            control of your health
          </p>
          <p>
            At Med Connect, we're dedicated to making healthcare more accessible
            and convenient. Our platform connects patients with top medical
            professionals, streamlining the appointment booking process
          </p>
        </div>
      </div>
      <div className="text-xl my-4">
        <p>
          WHY <span className="text-gray-700 font-semibold">CHOOSE US</span>
        </p>
      </div>
      <div className="flex flex-col md:flex-row mb-20">
        <div className="border px-10 md:px-16 py-8 sm:py-16 flex flex-col gap-5 text-[15px] hover:bg-primary hover:text-white transition-all duration-300 text-gray-600 cursor-pointer">
          <b>Efficiency</b>
          <p>
            Streamline your healthcare journey with our intuitive platform.
            Quickly find and book appointments with the right doctors, saving
            you time and effort.
          </p>
        </div>
        <div className="border px-10 md:px-16 py-8 sm:py-16 flex flex-col gap-5 text-[15px] hover:bg-primary hover:text-white transition-all duration-300 text-gray-600 cursor-pointer">
          <b>Convenience</b>
          <p>
            Book appointments anywhere, anytime. Our platform is designed to fit
            your busy schedule, allowing you to manage your healthcare on your
            terms.
          </p>
        </div>
        <div className="border px-10 md:px-16 py-8 sm:py-16 flex flex-col gap-5 text-[15px] hover:bg-primary hover:text-white transition-all duration-300 text-gray-600 cursor-pointer">
          <b>Personization</b>
          <p>
            Your health, your way. Our platform allows you to tailor your
            experience, from choosing the perfect doctor to scheduling
            appointments that suit your needs.
          </p>
        </div>
      </div>
    </div>
  );
}

export default About;
